set names utf8;
set charset utf8;
use allesvoordekeuken;
 ALTER TABLE artikels ADD COLUMN soort ENUM('F','NF') NOT NULL,
 ADD COLUMN garantie INT UNSIGNED,
 ADD COLUMN houdbaarheid INT UNSIGNED;