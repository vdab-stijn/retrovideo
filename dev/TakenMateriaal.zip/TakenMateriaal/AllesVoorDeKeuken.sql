set names utf8;
set charset utf8;

drop database if exists allesvoordekeuken;
CREATE DATABASE allesvoordekeuken charset UTF8;
USE allesvoordekeuken;

CREATE TABLE artikelgroepen (
  id int unsigned NOT NULL auto_increment primary key,
  naam varchar(50) NOT NULL
);

CREATE TABLE artikels (
  id int unsigned NOT NULL auto_increment primary key,
  naam varchar(50) NOT NULL,
  aankoopprijs decimal(10,2) NOT NULL,
  verkoopprijs decimal(10,2) NOT NULL,
  KEY Naam(naam)
);

create user if not exists cursist identified by 'cursist';
grant select,insert on artikelgroepen to cursist;
grant select,insert,update on artikels to cursist;